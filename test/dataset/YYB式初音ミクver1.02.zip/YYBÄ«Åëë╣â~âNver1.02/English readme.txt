﻿===================================================================================================
== model：YYB style Hatsune miku
== modeler：YYB
===================================================================================================
■About this Model

HI！
Thanks for downloading !
This model is Hatsune Miku MMD model creatived and produced by YYB
Please use this model within the limit of following matters

■Forbidden matters

•Being used to violate public and order or lacking wise and subtle judgment are forbidden
•Commercial use , Political use, Religious use, Used for forbidden works about R-18 or violence.( All forbidden ! )
•Can't be used to contempt the other countries and  Other people
•Some behaviors to confuse the original author and to other stakeholders are forbidden ( such as be used for Television、Animation production company、Magazinee . etc）
•Can't be used to belittle the original author、original Motion 
•Don't deceive the creator of this data（Contains claiming to be the creator of the model）

■About the distribution and remodeling

Some parts of this model can not be transplanted to other models
（e.g.：The twin tail and the waist machinery . etc）

You have to add this readme（japanese and English） and your own readme to the folder if you edit this model and distribute ( required !)

■Disclaimer

The producer of this model ( YYB )  shall not be responsible for any damage and loss caused or alleged to be caused by or in connection with using this model.

■Acknowledgments

MikuMikuDance		higuchuu(樋口優) 
PMDEditor	        KyokuhokuP（極北P）
Metasequoia             tetraface Inc.